#指导说明文档
本工具包为龙架构linux os下修改UEFI BIOS选项工具。主要包含以下四个文件：
efivar_manager.sh        > 选项导出、导入和展示，运行此脚本会有具体用法
efivar_import.txt        > 导入功能中文件导入模板，目前配置为默认配置，修改的话按照efivar_manager.sh中DEFAULT_BIN_VALUES进行修改，格式按照本文件。
efivar-39.tar.gz         > 本地efivar工具源码包
auto_compile_efivar.sh   > 自动安装本地efivar工具，默认使用的是efivar-39.tar.gz。如果系统有自带efivar，可忽略。

#特别注意：修改UEFI BIOS选项有可能会导致系统死机等异常情况，请在专业指导下进行修改。
