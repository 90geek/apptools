#!/bin/bash
# auto_compile_efivar.sh

# 自动安装efivar工具 v1.0
# 最后更新：2025-05-08
# 作者： wangjinwei@loongson.cn
# OS: Anolis OS 8.9  & linux 6.6(其他OS平台暂未验证)

# 配置参数
CURRENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EFI_DIR="${CURRENT_DIR}/efivar_bin"
SOURCE_TAR="${CURRENT_DIR}/efivar-39.tar.gz"

# 安装核心依赖（跳过mandoc）
install_deps() {
    local pkgs=(autoconf automake libtool gcc make pkg-config)
    
    if command -v dnf &>/dev/null; then
        sudo dnf install -y "${pkgs[@]}" || return 1
    elif command -v yum &>/dev/null; then
        sudo yum install -y "${pkgs[@]}" || return 1
    elif command -v apt &>/dev/null; then
        sudo apt install -y "${pkgs[@]}" || return 1
    else
        echo "错误：不支持的包管理器" >&2
        return 1
    fi
}

# 配置时禁用文档生成
#configure_build() {
#    ./configure \
#        --prefix="${EFI_DIR}" \
#        --disable-docs \         # 跳过man page生成
#        --bindir="${EFI_DIR}/bin" \
#        --libdir="${EFI_DIR}/lib"
#}

# 主流程
main() {
    # 清理旧构建
    rm -rf "${EFI_DIR}"
    
    # 安装依赖（不再需要mandoc）
    if ! install_deps; then
        echo "依赖安装失败，但尝试继续编译..." >&2
    fi

    # 解压源码
    mkdir -p "${EFI_DIR}/src"
    tar -zxvf "${SOURCE_TAR}" -C "${EFI_DIR}/src" --strip-components=1 || exit 1

    # 编译安装
    cd "${EFI_DIR}/src" || exit 1
    #autoreconf -ivf && \
    #configure_build && \
    #make -j$(nproc) && \
    sudo make install

    # 配置环境
    #echo "export PATH=\"${EFI_DIR}/bin:\$PATH\"" > "${EFI_DIR}/env.sh"
    #chmod +x "${EFI_DIR}/env.sh"
    #echo "编译完成！执行 source ${EFI_DIR}/env.sh 激活环境"

    # 验证安装结果
    if [ -x "/usr/bin/efivar" ]; then
        echo "安装成功！efivar路径：/usr/bin/efivar"
    else
        echo "错误：二进制文件未生成" >&2
        exit 1
    fi

    echo "环境配置完成！请运行./efivar_manager.sh"
}

main "$@"