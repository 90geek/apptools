#!/bin/bash
# EFI变量管理工具 v1.0
# 最后更新：2025-05-08
# 作者： wangjinwei@loongson.cn
# 适用：龙芯LoongArch架构服务器UEFI BIOS (其他平台未验证)
# OS: Anolis OS 8.9 & linux 6.6(其他OS平台暂未验证)

# 注意事项： 确保系统已安装efivar工具包，如果没有安装，请联网进行下载软件包或者运行工具包中的auto_compile_efivar.sh安装efivar.
# dnf -y install efivar-libs
# 输入efivar后提示下载efivar, 输入y，进行下载

# 静态配置
declare -r KEYWORDS=("Lang"
                     "FactoryData"
                     "UpdateFw"
                     "PasswdData"
                     "SmcUiCfg"
                     "PciSubSystemCfg"
                     "LegacyModeCfg"
                     "PrimaryDisplayCfg"
                     "BridgeDevCfg"
                     "NewWorkManager"
                     "BootNext"
                     "Timeout"
                     "BootRetryCount"
                     )
declare -r OUTPUT_FILE="EFIVars_$(date +%Y%m%d).txt"
declare -r LOG_FILE="/var/log/efi_manager.log"
declare -A DEFAULT_BIN_VALUES=(
    # 按照固件中的结构体进行配置，修改参考用户手册、严格小端序格式。# 双字节对齐
    [Lang]="656e6700"     # [默认值： \65 6e 67 00] 代表的是：eng（英文）. (修改中文chs: \63 68 73 00)
    # Security
        # Secure Boot Configuration (不支持)
        # [SecureBoot]="01"     # [默认值： \00, Standard > 00 Or Custom > 01] 代表的是：Secure Boot Mode. 
        # Factory (不留接口)
        [FactoryData]="01"     # [默认值： \x01] 代表的是：Support CMOS Restore Factory. 
        # Password
        [PasswdData]="00000000000000000000000000000000\
                      00000000000000000000000000000000\
                      00000000000000000000000000000000\
                      00000000000000000000000000000000\
                      00000000000000000000000000000000\
                      00000000000000000000000000000000\
                      00000000000000000000000000000000\
                      00000000000000000000000000000000\
                      0000"
        # 分别代表的是：Set Administrator password (长度0x40) 和 Set User password (长度0x40)、IsAdminSet、CurrentPwType. （UINT16 [0x20] + UINT16 [0x20] + UINT8 + UINT8）
        # [默认值： 
        # 00000000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
        # 00000010 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
        # 00000020 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
        # 00000030 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
        # 00000040 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
        # 00000050 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
        # 00000060 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
        # 00000070 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
        # 00000080 00 00
        # ]
        # 例子：管理员密码loongson@88,用户密码loongson@99,并且将IsAdminSet设置为1.
        # [PasswdData]="6c006f006f006e00670073006f006e00\
        #              40003800380000000000000000000000\
        #              00000000000000000000000000000000\
        #              00000000000000000000000000000000\
        #              6c006f006f006e00670073006f006e00\
        #              40003900390000000000000000000000\
        #              00000000000000000000000000000000\
        #              00000000000000000000000000000000\
        #              0100"
        # Update Firmware
        [UpdateFw]="010000"     # \[默认值： \01\00\00] 分别代表的是：Smbios Information 和 BIOS Configuration以及Update Validation.
    # Advanced
        # System Management Controller [注意：桌面和服务器选项不同，注意区分]
        [SmcUiCfg]="010000"     # \[默认值： \01\00\00] 分别代表的是：SMC Support 和 Dvfs Support以及LPC Transfer Support. 
        # PCI Subsystem Settings
        [PciSubSystemCfg]="0101000101"     # [默认值： \01\01\00\01\01] 分别代表的是：Above 4G Decoding、SR-IOV Switch、ResizableBar Switch、GPU Emu Switch、PCIe DSM#5 Support
        # Legacy Boot Mode
        [LegacyModeCfg]="0001"     # [6000服务器默认值： \00\01; 5000服务器默认值： \01\01] 分别代表的是：Mode Control Select 和 ISO File System Select 
        # Primary Display
        [PrimaryDisplayCfg]="000100"     # [默认值： \00\01\00] 分别代表的是：Primary Display 和 SuppressOnboardVideo 、SuppressBMCVideo, 用户只修改第一项值（Primary Display），范围【00-01-02-03】
        # Ipmi Configuration (不留接口)
    # Device Manager
        # Control Various Controllers
            # ATA Drive Setup (UINT8 + UINT8 + UINT8 + UINT8)
            # USB Setup (UINT8 + UINT8 + UINT8)
            # NetWork Setup (UINT8 + UINT8)
            # WakeUp Setup (UINT8 + UINT8)
            # Iommu Setup (UINT8)
            # Power Restore Policy Setup (UINT8)
            # Slot 7A0 F0 Configure (UINT32 + UINT8 + UINT8 + UINT32)  > (Mode + EnableFlag + Inversion + Gen ) 下同↓
            # Slot 7A0 F1 Configure (UINT32 + UINT8 + UINT8 + UINT32)
            # Slot 7A0 H Configure (UINT32 + UINT8 + UINT8 + UINT32)
            # Slot 7A0 G0 Configure (UINT32 + UINT8 + UINT8 + UINT32)
            # Slot 7A1 F0 Configure (UINT32 + UINT8 + UINT8 + UINT32)  > 6000服务器没有7A1设置，忽略
            # Slot 7A1 F1 Configure (UINT32 + UINT8 + UINT8 + UINT32)
            # Slot 7A1 H Configure (UINT32 + UINT8 + UINT8 + UINT32)
            # Slot 7A1 G0 Configure (UINT32 + UINT8 + UINT8 + UINT32)
            [BridgeDevCfg]="01010101\
                            010101\
                            0000\
                            0100\
                            00\
                            02\
                            01000000010003000000\
                            04000000010003000000\
                            08000000010003000000\
                            08000000010003000000\
                            00000000000000000000\
                            00683f0e9000000000b8\
                            8a299000000000ac6e0d\
                            90000000000400000000\
                            00000000000000000000\
                            00340800000200000000"
            # [6000服务器默认值：
            # 00000000  01 01 01 01 01 01 01 00  00 01 00 00 02 01 00 00  |................|
            # 00000010  00 01 00 03 00 00 00 04  00 00 00 01 00 03 00 00  |................|
            # 00000020  00 08 00 00 00 01 00 03  00 00 00 08 00 00 00 01  |................|
            # 00000030  00 03 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
            # 00000040  68 3f 0e 90 00 00 00 00  b8 8a 29 90 00 00 00 00  |h?........).....|
            # 00000050  ac 6e 0d 90 00 00 00 00  04 00 00 00 00 00 00 00  |.n..............|
            # 00000060  00 00 00 00 00 00 00 00  34 08 00 00 02 00 00 00  |........4.......|
            # 00000070  00                                                |.               |
            #]
            # 5000服务器配置
            # [BridgeDevCfg]="01010101\
            #                010101\
            #                0000\
            #                0100\
            #                00\
            #                02\
            #                01000000010003000000\
            #                04000000010003000000\
            #                08000000010003000000\
            #                08000000010003000000\
            #                00000000000000000000\
            #                04000000010003000000\
            #                04000000010003000000\
            #                08000000010003000000\
            #                08000000010003000000\
            #                00000000000000000000"
            # [5000服务器默认值：
            # 00000000  01 01 01 01 01 01 01 00  00 01 00 00 02 01 00 00
            # 00000010  00 01 00 03 00 00 00 04  00 00 00 01 00 03 00 00
            # 00000020  00 08 00 00 00 01 00 03  00 00 00 08 00 00 00 01
            # 00000030  00 03 00 00 00 00 00 00  00 00 00 00 00 00 00 04
            # 00000040  00 00 00 01 00 03 00 00  00 04 00 00 00 01 00 03
            # 00000050  00 00 00 08 00 00 00 01  00 03 00 00 00 08 00 00
            # 00000060  00 01 00 03 00 00 00 00  00 00 00 00 00 00 00 00
            # 00000070  00 
            #]
        # Network Control
        [NewWorkManager]="000101010204081020"
        # [6000服务器默认值： \00\01\01\01\02\04\08\10\20]
        # [NewWorkManager]="000101010204040404"
        # [5000服务器默认值： \00\01\01\01\02\04\04\04\04] 
        # 分别代表的是：NetworkProtocolOff/HttpProtocolOff/HttpBootOff/PxeOff/PxeDhcpDiscoverTryCount/PxeDhcpDiscoverTimeout0/PxeDhcpDiscoverTimeout1/PxeDhcpDiscoverTimeout2/PxeDhcpDiscoverTimeout3
        # iSCSI Configuration （不留接口）
        # Tls Auth Configuration （不留接口）
        # Network Device List （不留接口）
    # Boot Maintenance Manager
        # [BootNext]="0000"     # [默认值： \00\00] 代表的是：Boot Next Value   (双字节-UINT16)
        [Timeout]="0300"     # [默认值： \03\00： 超时时间：3] 代表的是：Auto Boot Time-out   (双字节-UINT16)
        [BootRetryCount]="0000"     # [默认值： \00\00] 代表的是：Boot Retry Count  (双字节-UINT16)
)

# 日志初始化
exec > >(tee -a "$LOG_FILE") 2>&1

# 权限预检
check_privileges() {
    if ! ls /sys/firmware/efi/efivars &>/dev/null; then
    #5000 if ! ls /sys/firmware/efi/vars &>/dev/null; then
        echo "错误：EFI变量访问未授权（Secure Boot可能已启用）" >&2
        exit 1
    fi
    if ! sudo -v; then
        echo "错误：需要root权限执行此操作" >&2
        exit 1
    fi
}

# 导出功能
export_vars() {
    > "$OUTPUT_FILE"
    local matched_vars=()

    # 生成安全正则表达式
    local regex_pattern=$(
        printf '%s\n' "${KEYWORDS[@]}" |
        sed 's/[]$*^|+?.\\[]/\\&/g; # 转义特殊字符
             s/^/.*-/;              # 添加GUID前缀匹配
             s/$/$/;                # 行尾锚定
             s/ /\\|/g' |           # 空格处理
        tr '\n' '|' |
        sed 's/|$//'
    )

    # 调试信息
    #echo "生成的正则表达式：$regex_pattern" | tee -a "$LOG_FILE"
    
    # 精确收集变量
    while read -r full_name; do
        var_name="${full_name##*-}"
        if [[ " ${KEYWORDS[@]} " =~ " $var_name " ]]; then
            matched_vars+=("$full_name")
        fi
    done < <(
        efivar -l 2>/dev/null |
        grep -E "$regex_pattern"
    )

    # 错误处理
    if ((${#matched_vars[@]} == 0)); then
        echo "错误：未找到有效变量，请检查：" | tee -a "$LOG_FILE"
        echo "1. 当前KEYWORDS：" "${KEYWORDS[@]}" | tee -a "$LOG_FILE"
        echo "2. 系统变量列表：" | tee -a "$LOG_FILE"
        sudo efivar -l | tee -a "$LOG_FILE"
        return 1
    fi

    # 结构化输出
    for idx in "${!matched_vars[@]}"; do
        {
            printf "[%d] %s\n" "$((idx+1))" "${matched_vars[idx]}"
            echo "========================================"
            sudo efivar -n "${matched_vars[idx]}"
            echo
        } >> "$OUTPUT_FILE"
    done

    echo "导出完成！共找到 ${#matched_vars[@]} 个变量"
}

# 变量收集
collect_efi_vars() {
    local -n arr=$1
    while read -r full_name; do
        for keyword in "${KEYWORDS[@]}"; do
            [[ "$full_name" == *"-${keyword}" ]] && arr+=("$full_name")
        done
    done < <(efivar -l 2>/dev/null)
}

# 手动输入模式
manual_input() {
    declare -a valid_vars  # 仅存储有效存在的变量

    # 生成精准正则表达式（修复LangCodes误匹配问题）
    local regex_pattern=$(
        printf '%s\n' "${KEYWORDS[@]}" |
        sed 's/[]$*^|+?.\\[]/\\&/g; # 转义特殊字符
             s/^/.*-/;             # 添加GUID前缀匹配
             s/$/$/;               # 行尾锚定
             s/ /\\|/g' |          # 空格处理
        tr '\n' '|' |
        sed 's/|$//'
    )

    # 变量收集流程
    while read -r full_name; do
        # 提取变量名并二次验证
        var_name="${full_name##*-}"
        
        # 双重验证：1)正则匹配完整变量名 2)精确匹配关键字 
        if [[ "$full_name" =~ ${regex_pattern} ]] && 
           [[ " ${KEYWORDS[@]} " =~ " $var_name " ]] &&
           sudo efivar -n "$full_name" &>/dev/null; then
            valid_vars+=("$full_name")
        fi
    done < <(efivar -l 2>/dev/null)

    # 动态列宽计算
    local max_name_len=0
    for var in "${valid_vars[@]##*-}"; do
        (( ${#var} > max_name_len )) && max_name_len=${#var}
    done
    local col_width=$((max_name_len + 8))

    # 表格输出
    echo "========================================"
    printf "\033[32m%-*s\033[0m\n" "$col_width" "可用变量列表"
    echo "----------------------------------------"
    
    for i in "${!valid_vars[@]}"; do
        var_name="${valid_vars[$i]##*-}"
        printf "\033[33m%2d)\033[0m \033[37m%-*s\033[0m\n" \
               $((i+1)) "$col_width" "$var_name"
    done
    echo "----------------------------------------"

    # 交互逻辑
    while :; do
        read -p "输入变量序号（1-${#valid_vars[@]}）或0返回: " idx
        [[ "$idx" == 0 ]] && break
        
        # 输入验证增强
        if ! [[ "$idx" =~ ^[0-9]+$ ]] || (( idx < 1 || idx > ${#valid_vars[@]} )); then
            echo -e "\033[31m错误：请输入1-${#valid_vars[@]}之间的数字\033[0m" >&2
            continue
        fi

        # 变量信息展示
        selected_var="${valid_vars[$((idx-1))]}"
        var_name="${selected_var##*-}"
        
        echo "────────────────────────────────────"
        echo -e "\033[32m当前变量值 [${var_name}]\033[0m"
        echo "────────────────────────────────────"
        sudo efivar -n "$selected_var" | 
        awk 'NR>1 {gsub(/.*: /,""); printf "\033[37m%s\033[0m\n", $0}'
        echo "────────────────────────────────────"

        # HEX输入处理
        while :; do
            read -p "为${var_name}输入HEX值（如0100）: " user_input
            clean_hex=$(echo "$user_input" | tr -dc '[:xdigit:]' | tr '[:lower:]' '[:upper:]')
            
            # 空输入处理（新增回车保护）
            if [[ -z "$clean_hex" ]]; then
                echo -e "\033[33m注意：输入为空，放弃修改\033[0m"
                continue 2
            fi

            # 写入验证
            tmp_file=$(mktemp)
            if echo -n "$clean_hex" | xxd -r -p > "$tmp_file" &&
               sudo efivar -w -n "$selected_var" -f "$tmp_file"; then
                echo -e "\033[32m✔ 更新成功\033[0m"
                break
            else
                echo -e "\033[31m✘ 写入失败（错误码 $?）\033[0m" >&2
            fi
            rm -f "$tmp_file"
        done
    done
}

# 文件批量导入
file_import() {
    read -p "▸ 输入TXT文件路径: " import_file
    [[ -f "$import_file" ]] || { echo "文件不存在"; return; }

    # 格式校验正则表达式
    local hex_regex='^[0-9a-fA-F]+$'

    while IFS='=' read -r var_name hex_value; do
        # 跳过注释和空行
        [[ "$var_name" =~ ^#|^$ ]] && continue
        
        # 输入净化
        var_name=$(echo "$var_name" | tr -d '[:space:]')
        hex_value=$(echo "$hex_value" | tr -d '[:space:]')

        # 格式校验
        if ! [[ "$hex_value" =~ $hex_regex ]]; then
            echo "✘ $var_name 值 '$hex_value' 包含非法字符" >&2
            continue
        fi

        # 构造完整变量名（需匹配GUID）
        full_name=$(efivar -l 2>/dev/null | grep -E ".*-${var_name}$" | head -1)
        [[ -z "$full_name" ]] && {
            echo "✘ $var_name 不存在于系统变量" >&2
            continue
        }

        # 二进制转换
        tmp_file=$(mktemp)
        if echo -n "$hex_value" | xxd -r -p > "$tmp_file"; then
            if sudo efivar -w -n "$full_name" -f "$tmp_file"; then
                echo "✔ $var_name 导入成功"
            else
                echo "✘ $var_name 写入失败（错误码：$?）" >&2
            fi
        else
            echo "✘ $var_name 二进制转换失败" >&2
        fi
        rm -f "$tmp_file"
    done < <(grep -v '^#' "$import_file") 
}

# 默认值写入
apply_defaults() {
    # 生成临时文件列表
    local tmp_list=$(mktemp)
    efivar -l 2>/dev/null > "$tmp_list"

    # 遍历所有预设变量
    for var_name in "${!DEFAULT_BIN_VALUES[@]}"; do
        # 匹配完整变量名 (GUID-VarName)
        grep -E ".*-${var_name}$" "$tmp_list" | while read -r full_var; do
            # 生成二进制数据
            tmp_bin=$(mktemp)
            echo "${DEFAULT_BIN_VALUES[$var_name]}" | xxd -r -p > "$tmp_bin"
            
            # 写入验证
            if sudo efivar -w -n "$full_var" -f "$tmp_bin"; then
                echo "[更新成功] $var_name"
            else
                echo "[更新失败] $var_name (错误码:$?)"
            fi
            
            rm -f "$tmp_bin"
        done
    done

    rm -f "$tmp_list"
}

# 导入功能入口（三种模式集成）
import_vars() {
    PS3="请选择导入模式："
    select mode in "手动输入" "文件批量导入" "使用默认值"; do
        case $REPLY in
        1) manual_input; break ;;
        2) file_import; break ;;
        3) apply_defaults; break ;;
        *) echo "无效选项";;
        esac
    done
}

# 参数解析
parse_arguments() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -e|--export)
                check_privileges
                export_vars
                shift ;;
            -i|--import)
                check_privileges
                import_vars
                shift ;;
            -l|--list)
                check_privileges
                declare -a vars
                collect_efi_vars vars
                echo "GUID-变量名"
                for var in "${vars[@]}"; do
                    printf "%-45s\n" "$var"  # 仅打印GUID-变量名
                done
                shift ;;
            -h|--help)
                show_help
                exit 0 ;;
            *)
                echo "未知参数: $1" >&2
                exit 1 ;;
        esac
    done
}

# 帮助信息
show_help() {
    echo "用法: $0 [选项]"
    echo "选项:"
    echo "  -e, --export  导出EFI变量到${OUTPUT_FILE}"
    echo "  -i, --import  交互式修改EFI变量（三种模式）"
    echo "  -l, --list    列出所有支持的EFI变量及当前值"
    echo "  -h, --help    显示本帮助信息"
    echo
    echo "示例:"
    echo "  批量导出变量: sudo $0 -e"
    echo "  交互式修改:    sudo $0 -i"
    echo "  快速列表:     sudo $0 -l"
}

# 主程序入口
main() {
    [[ $# -eq 0 ]] && show_help && exit 1
    parse_arguments "$@"
}

main "$@"
